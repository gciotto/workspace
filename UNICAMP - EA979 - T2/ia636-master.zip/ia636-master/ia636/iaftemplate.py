# -*- encoding: utf-8 -*-
# Module iaftemplate

def iaftemplate(f):
    import numpy as np

    H,W = f.shape
    return np.zeros((H,W))

