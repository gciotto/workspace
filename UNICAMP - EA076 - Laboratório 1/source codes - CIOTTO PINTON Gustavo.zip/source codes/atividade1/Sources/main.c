/*
 * main implementation: use this 'C' sample to create your own application
 *
 */





#include "derivative.h" /* include peripheral declarations */



int main(void)
{
	int counter = 0;
	
	
	
	
	for(;;) {	   
	   	counter++;
	}
	
	return 0;
}
