/**
 * 
 */
package bibliotheque;

import bibliotheque.ihm.ControleurBibliotheque;
import bibliotheque.ihm.GestionnaireIHM;
import bibliotheque.ihm.swt.SWTGestionnaireIHM;
import bibliotheque.metier.IBibliotheque;
import bibliotheque.metier.impl.Bibliotheque;
import bibliotheque.util.ChargementBibliotheque;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Lancement {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param args
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public static void main(String[] args) {
		// begin-user-code
		GestionnaireIHM ihm = new SWTGestionnaireIHM();
		IBibliotheque bibliotheque = new Bibliotheque();
		ChargementBibliotheque.chargement(bibliotheque);
		ControleurBibliotheque controleur = new ControleurBibliotheque(ihm,
				bibliotheque);
		controleur.lancement();
		// end-user-code
	}
}