/**
 * 
 */
package bibliotheque.metier;

/** 
 * <!-- begin-UML-doc -->
 * <p>Interface sp�cifiant les besoins d'acc�s � un exemplaire.</p>
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public interface IExemplaire {
	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne l'ouvrage d�crivant cet exemplaire</p>
	 * <!-- end-UML-doc -->
	 * @return <p>l'objet ouvrage associ�</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IOuvrage getOuvrage();

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean estEmprunte();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p >Retourne le code-barres de l'exemplaire.</p><p >l'IHM fournie suppose que ce code-barres est constitu� des deux lettres EX suivies d'un entier ; par exemple EX2</p><p ></p>
	 * <!-- end-UML-doc -->
	 * @return <p>le code-barres de l'exemplaire</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String getIdentifiant();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne null si l'exemplaire est disponible, l'objet emprunt associ� si l'exemplaire est emprunt�</p>
	 * <!-- end-UML-doc -->
	 * @return <p> l'objet emprunt associ� ou null</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IEmprunt getEmprunt();
}