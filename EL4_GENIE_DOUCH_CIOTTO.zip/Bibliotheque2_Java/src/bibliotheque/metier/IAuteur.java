/**
 * 
 */
package bibliotheque.metier;

/** 
 * <!-- begin-UML-doc -->
 * <p>Interface sp�cifiant les besoins d'acc�s � un auteur.</p>
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public interface IAuteur {
	/** 
	 * <!-- begin-UML-doc -->
	 * <p>retourne le nom de l'auteur</p>
	 * <!-- end-UML-doc -->
	 * @return <p>nom de l'auteur</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String getNom();
}