/**
 * 
 */
package bibliotheque.metier;

import java.util.Iterator;

/** 
 * <!-- begin-UML-doc -->
 * <p>Interface sp�cifiant les besoins d'acc�s � un ouvrage.</p>
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public interface IOuvrage {
	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le genre de cet ouvrage</p>
	 * <!-- end-UML-doc -->
	 * @return <p>le genre de l'ouvrage</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public GenreOuvrage getGenre();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le titre de cet ouvrage</p>
	 * <!-- end-UML-doc -->
	 * @return <p>le titre</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String getTitre();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne l'auteur ayant �crit cet ouvrage</p>
	 * <!-- end-UML-doc -->
	 * @return <p>l'objet auteur associ�</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IAuteur getAuteur();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le nombre d'exemplaires de cet ouvrage.</p>
	 * <!-- end-UML-doc -->
	 * @return <p>le nombre d'exemplaires</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getNombreExemplaires();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le nombre d'exemplaires de cet ouvrage emprunt�s</p>
	 * <!-- end-UML-doc -->
	 * @return <p>le nombre d'exemplaires emprunt�s</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getNombreEmprunts();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p >M�thode permettant de parcourir les exemplaires de l'ouvrage.</p><p >Si, par exemple, vous stockez les exemplaires dans un HashSet nomm� exemplaires, vous pouvez utiliser le code suivant :</p><p class="codesample">return Collections.&lt;IExemplaire&gt; unmodifiableCollection(exemplaires).iterator();</p>
	 * <!-- end-UML-doc -->
	 * @return <p>un it�rateur sur les exemplaires de cet ouvrage.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Iterator<IExemplaire> iterateurExemplaires();
}