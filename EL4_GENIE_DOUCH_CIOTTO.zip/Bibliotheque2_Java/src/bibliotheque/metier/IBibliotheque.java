/**
 * 
 */
package bibliotheque.metier;

import java.util.GregorianCalendar;
import java.util.Iterator;

/** 
 * <!-- begin-UML-doc -->
 * <p>Interface principale d'acc�s aux objets m�tiers.</p>
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public interface IBibliotheque {

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode appel�e par le contr�leur quand l'utilisateur demande l'ajout d'un nouvel abonn�.</p>
	 * <!-- end-UML-doc -->
	 * @param nom <p>nom du nouvel abonn�</p>
	 * @param date <p>date d'inscription</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void nouvelAbonne(String nom, GregorianCalendar date);

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode appel�e par le contr�leur quand l'utilisateur demande l'ajout d'un nouvel ouvrage.</p><p></p>
	 * <!-- end-UML-doc -->
	 * @param titre <p>titre de l'ouvrage</p>
	 * @param auteur <p>Nom de l'auteur</p>
	 * @param genre <p>genre de l'ouvrage</p>
	 * @param nombreExemplaires <p>nombre d'exemplaires de l'ouvrage</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void nouvelOuvrage(String titre, String auteur, GenreOuvrage genre,
			int nombreExemplaires);

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode appel�e par le contr�leur quand l'utilisateur enregistre un nouvel emprunt</p>
	 * <!-- end-UML-doc -->
	 * @param abonne <p>abonne effectuant l'emprunt</p>
	 * @param exemplaire <p>exemplaire emprunt�</p>
	 * @param date <p>date de d�but de l'emprunt</p>
	 * @return <p>message � afficher (null s'il n'y a rien � afficher)</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String nouvelEmprunt(IAbonne abonne, IExemplaire exemplaire,
			GregorianCalendar date);

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode appel�e par le contr�leur quand l'utilisateur enregistre la restitution d'un exemplaire</p>
	 * <!-- end-UML-doc -->
	 * @param exemplaire <p>exemplaire rendu</p>
	 * @param date <p>date de la restitution</p>
	 * @return <p>message � afficher (null s'il n'y a rien � afficher)</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String nouvelleRestitution(IExemplaire exemplaire,
			GregorianCalendar date);

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode permettant de chercher un abonn� dont on connait le code-barres</p>
	 * <!-- end-UML-doc -->
	 * @param code <p>code-barres identifiant l'abonn�</p>
	 * @return <p>abonn� correspondant (null s'il n'y en a pas)</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IAbonne trouveAbonne(String code);

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode permettant de chercher un exemplaire dont on connait le code-barres</p>
	 * <!-- end-UML-doc -->
	 * @param code <p>code-barres identifiant l'exemplaire</p>
	 * @return <p>exemplaire correspondant (null s'il n'y en a pas)</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IExemplaire trouveExemplaire(String code);

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode permettant de parcourir les abonn�s de la biblioth�que.</p><p >Si, par exemple, vous stockez les abonn�s dans une HashMap nomm�e abonnes, vous pouvez utiliser le code suivant :</p><p class="codesample">    return Collections.&lt;IAbonne&gt; unmodifiableCollection(abonnes.values()).iterator();</p>
	 * <!-- end-UML-doc -->
	 * @return <p>un it�rateur sur les abonn�s de la biblioth�que</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Iterator<IAbonne> iterateurAbonnes();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode permettant de parcourir les ouvrages de la biblioth�que.</p><p>Si, par exemple, vous stockez les ouvrages dans un HashSet nomm� ouvrages, vous pouvez utiliser le code suivant :</p><p class="codesample">return Collections.&lt;IOuvrage&gt; unmodifiableCollection(ouvrages).iterator();</p>
	 * <!-- end-UML-doc -->
	 * @return <p>un it�rateur sur les ouvrages de la biblioth�que</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Iterator<IOuvrage> iterateurOuvrages();
}