/**
 * 
 */
package bibliotheque.metier.impl;

import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.Iterator;

import bibliotheque.metier.GenreOuvrage;
import bibliotheque.metier.IAbonne;
import bibliotheque.metier.IAuteur;
import bibliotheque.metier.IBibliotheque;
import bibliotheque.metier.IEmprunt;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import bibliotheque.metier.IExemplaire;
import bibliotheque.metier.IOuvrage;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Bibliotheque implements IBibliotheque {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private HashMap<String, Abonne> abonnes = new HashMap<String, Abonne>();
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Integer nbExemplaires = 0;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private HashSet<Ouvrage> ouvrages = new HashSet<Ouvrage>();

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private HashSet<Auteur> auteurs = new HashSet<Auteur>();

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param id
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Abonne trouveAbonne(String id) {
		// begin-user-code
		// TODO Auto-generated method stub
		return abonnes.get(id);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param id
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Exemplaire trouveExemplaire(String id) {
		// begin-user-code
		// TODO Auto-generated method stub

		Iterator<IOuvrage> iteratorOuvrage = this.iterateurOuvrages();

		while (iteratorOuvrage.hasNext()) {

			Ouvrage ouvrageActuel = (Ouvrage) iteratorOuvrage.next();

			Iterator<IExemplaire> iteratorExemplaires = ouvrageActuel
					.iterateurExemplaires();

			while (iteratorExemplaires.hasNext()) {

				Exemplaire actuel = (Exemplaire) iteratorExemplaires.next();

				if (actuel.getIdentifiant().compareTo(id) == 0)
					return actuel;
			}

		}

		return null;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param nom
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Auteur nouvelAuteur(String nom) {
		// begin-user-code

		Auteur nouveauAuteur = new Auteur(nom);

		this.auteurs.add(nouveauAuteur);

		return nouveauAuteur;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode appel�e par le contr�leur quand l'utilisateur demande l'ajout d'un nouvel abonn�.</p>
	 * <!-- end-UML-doc -->
	 * @param nom <p>nom du nouvel abonn�</p>
	 * @param date <p>date d'inscription</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void nouvelAbonne(String nom, GregorianCalendar date) {
		// begin-user-code

		String key = "AB" + abonnes.size();
		Abonne nouveauAbonne = new Abonne(nom, date, true, key);

		this.abonnes.put(key, nouveauAbonne);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode appel�e par le contr�leur quand l'utilisateur demande l'ajout d'un nouvel ouvrage.</p><p></p>
	 * <!-- end-UML-doc -->
	 * @param titre <p>titre de l'ouvrage</p>
	 * @param auteur <p>Nom de l'auteur</p>
	 * @param genre <p>genre de l'ouvrage</p>
	 * @param nombreExemplaires <p>nombre d'exemplaires de l'ouvrage</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void nouvelOuvrage(String titre, String auteur, GenreOuvrage genre,
			int nombreExemplaires) {
		// begin-user-code
		// TODO Auto-generated method stub

		Iterator<Auteur> iteratorAuteur = this.auteurs.iterator();
		Auteur a = null;

		while (iteratorAuteur.hasNext()) {
			Auteur actuel = iteratorAuteur.next();
			if (actuel.getNom().compareTo(auteur) == 0)
				a = actuel;
		}

		if (a == null)
			a = nouvelAuteur(auteur);

		Ouvrage nouvelleOuvrage = new Ouvrage(a, genre, titre);

		for (int i = 0; i < nombreExemplaires; i++) {
			nouvelleOuvrage.ajouterExemplaire(new Exemplaire("EX"
					+ nbExemplaires, nouvelleOuvrage), "EX" + nbExemplaires);
			nbExemplaires++;
		}

		this.ouvrages.add(nouvelleOuvrage);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode appel�e par le contr�leur quand l'utilisateur enregistre un nouvel emprunt</p>
	 * <!-- end-UML-doc -->
	 * @param abonne <p>abonne effectuant l'emprunt</p>
	 * @param exemplaire <p>exemplaire emprunt�</p>
	 * @param date <p>date de d�but de l'emprunt</p>
	 * @return <p>message � afficher (null s'il n'y a rien � afficher)</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String nouvelEmprunt(IAbonne abonne, IExemplaire exemplaire,
			GregorianCalendar date) {
		// begin-user-code
		// TODO Auto-generated method stub

		if (!abonne.peutEmprunter())
			return "Abonne ne peut pas emprunter!";

		if (exemplaire.estEmprunte())
			return "Exemplaire deja emprunte!";

		Exemplaire e = (Exemplaire) exemplaire;
		Abonne a = (Abonne) abonne;

		Emprunt nouveauEmprunt = new Emprunt(e, a, date);

		e.setEmprunt(nouveauEmprunt);
		a.emprunter(nouveauEmprunt);

		//abonne

		return "Emprunt reussi";
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode appel�e par le contr�leur quand l'utilisateur enregistre la restitution d'un exemplaire</p>
	 * <!-- end-UML-doc -->
	 * @param exemplaire <p>exemplaire rendu</p>
	 * @param date <p>date de la restitution</p>
	 * @return <p>message � afficher (null s'il n'y a rien � afficher)</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String nouvelleRestitution(IExemplaire exemplaire,
			GregorianCalendar date) {
		// begin-user-code
		// TODO Auto-generated method stub

		Exemplaire e = (Exemplaire) exemplaire;

		if (!e.estEmprunte())
			return "Exemplaire n'est pas emprunte!";

		Iterator<IAbonne> iteratorAbonne = this.iterateurAbonnes();
		Abonne a = null;

		while (iteratorAbonne.hasNext() && a == null) {

			Abonne actuel = (Abonne) iteratorAbonne.next();
			Iterator<IEmprunt> iteratorEmprunts = actuel.iterateurEmprunts();

			while (iteratorEmprunts.hasNext() && a == null) {
				Emprunt emp = (Emprunt) iteratorEmprunts.next();
				if (emp.getExemplaire().getIdentifiant()
						.compareTo(e.getIdentifiant()) == 0) {
					a = actuel;
					a.restituer( emp );
			        if (emp.getDepassementRestitution( date ) > 0)
			            a.ajouteMalus( emp.getDepassementRestitution( date ) );
					emp.termine();
				}
			}
		}

		return "Restituion reussie!";
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode permettant de parcourir les abonn�s de la biblioth�que.</p><p >Si, par exemple, vous stockez les abonn�s dans une HashMap nomm�e abonnes, vous pouvez utiliser le code suivant :</p><p class="codesample">    return Collections.&lt;IAbonne&gt; unmodifiableCollection(abonnes.values()).iterator();</p>
	 * <!-- end-UML-doc -->
	 * @return <p>un it�rateur sur les abonn�s de la biblioth�que</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Iterator<IAbonne> iterateurAbonnes() {
		// begin-user-code
		// TODO Auto-generated method stub
		return Collections.<IAbonne> unmodifiableCollection(abonnes.values())
				.iterator();
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode permettant de parcourir les ouvrages de la biblioth�que.</p><p>Si, par exemple, vous stockez les ouvrages dans un HashSet nomm� ouvrages, vous pouvez utiliser le code suivant :</p><p class="codesample">return Collections.&lt;IOuvrage&gt; unmodifiableCollection(ouvrages).iterator();</p>
	 * <!-- end-UML-doc -->
	 * @return <p>un it�rateur sur les ouvrages de la biblioth�que</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Iterator<IOuvrage> iterateurOuvrages() {
		// begin-user-code
		// TODO Auto-generated method stub
		return Collections.<IOuvrage> unmodifiableCollection(ouvrages)
				.iterator();
		// end-user-code
	}
}