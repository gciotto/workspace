/**
 * 
 */
package bibliotheque.metier.impl;

import java.util.GregorianCalendar;

import bibliotheque.metier.IExemplaire;
import bibliotheque.metier.IAbonne;
import bibliotheque.metier.IEmprunt;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Emprunt implements IEmprunt {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Abonne abonne;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private GregorianCalendar dateDebut;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Exemplaire exemplaire;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Exemplaire getExemplaire() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.exemplaire;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param exemplaire
	 * @param abonne
	 * @param dateDebut
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Emprunt(Exemplaire exemplaire, Abonne abonne,
			GregorianCalendar dateDebut) {
		// begin-user-code
		this.abonne = abonne;
		this.exemplaire = exemplaire;
		this.dateDebut = dateDebut;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public GregorianCalendar getDateDebut() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.dateDebut;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Abonne getAbonne() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.abonne;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le nombre de jours de d�passement de cet emprunt (0 s'il n'y a pas de d�passement).</p>
	 * <!-- end-UML-doc -->
	 * @param date <p>date actuelle</p>
	 * @return <p>le nombre de jours de d�passement de cet emprunt (0 s'il n'y a pas de d�passement).</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getDepassementRestitution(GregorianCalendar date) {
		// begin-user-code
		// TODO Auto-generated method stub
		long difference = (date.getTimeInMillis() - dateDebut.getTimeInMillis())
				/ (1000 * 60 * 60 * 24) - 28;
		
		if (difference <= 0) return 0;
		
		return (int) difference;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Indique que l'exemplaire a �t� rendu et que l'emprunt est termin�.</p><p>L'abonn� ayant effectu� cet emprunt et l'exemplaire concern� n'ont pas �t� inform�s de cette fin d'emprunt : c'est le r�le de cette m�thode.</p>
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void termine() {
		// begin-user-code
		// TODO Auto-generated method stub
	    this.exemplaire.setEmprunt( null );
		// end-user-code
	}
}