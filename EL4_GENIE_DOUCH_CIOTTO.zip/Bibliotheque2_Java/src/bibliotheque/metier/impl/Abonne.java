/**
 * 
 */
package bibliotheque.metier.impl;

import java.util.*;

import bibliotheque.metier.IAbonne;

import java.util.HashSet;
import java.util.Collections;
import java.util.HashMap;
import java.util.GregorianCalendar;
import java.util.Iterator;
import bibliotheque.metier.IEmprunt;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Abonne implements IAbonne {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private HashSet<Emprunt> emprunts;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Integer malus;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Integer exemplairesEmpruntes;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Integer exemplairesEnRetard;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Boolean aPaye;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private GregorianCalendar dateInscription;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private String nom;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private String key;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param nom
	 * @param date
	 * @param aPaye
	 * @param key
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Abonne(String nom, GregorianCalendar date, Boolean aPaye, String key) {
		// begin-user-code
		// TODO Auto-generated method stub

		this.nom = nom;
		this.key = key;
		this.dateInscription = date;
		this.aPaye = aPaye;
		this.malus = 0;

		this.exemplairesEmpruntes = 0;
		this.exemplairesEnRetard = 0;

		emprunts = new HashSet<Emprunt>();
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param emprunt
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean restituer(Emprunt emprunt) {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.emprunts.remove( emprunt );
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param emprunt
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void emprunter(Emprunt emprunt) {
		// begin-user-code
		// TODO Auto-generated method stub

		this.emprunts.add(emprunt);

		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean peutEmprunter() {
		// begin-user-code
		// TODO Auto-generated method stub

		if (this.malus == 0 && aPaye && this.emprunts.size() < 5)
			return true;

		return false;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String getIdentifiant() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.key;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getMalus() {
		// begin-user-code
		// TODO Auto-generated method stub
		return malus;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public GregorianCalendar getDateFinValiditeInscription() {
		// begin-user-code
		// TODO Auto-generated method stub

		return new GregorianCalendar(
				dateInscription.get(GregorianCalendar.YEAR) + 1,
				dateInscription.get(GregorianCalendar.MONTH),
				dateInscription.get(GregorianCalendar.DAY_OF_MONTH));
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getNombreEmprunts() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.emprunts.size();
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ajout
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void ajouteMalus(int ajout) {
		// begin-user-code
		// TODO Auto-generated method stub

		/***
		GregorianCalendar g = null;
		        
		 ***/
		this.malus += ajout;

		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String getNom() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.nom;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Op�ration effectu�e sur chaque abonn� ayant un malus non nul lors d'un changement de jour</p>
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void decrementeMalus() {
		// begin-user-code
		// TODO Auto-generated method stub
		this.malus--;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode permettant de parcourir les emprunts de l'abonn�.</p><p>Si, par exemple, vous stockez les emprunts dans un HashSet nomm� emprunts, vous pouvez utiliser le code suivant :</p><p class="codesample">return Collections.&lt;IEmprunt&gt; unmodifiableCollection(emprunts).iterator();</p>
	 * <!-- end-UML-doc -->
	 * @return <p>un it�rateur sur les emprunts en cours de l'abonn�.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Iterator<IEmprunt> iterateurEmprunts() {
		// begin-user-code
		// TODO Auto-generated method stub
		return Collections.<IEmprunt> unmodifiableCollection(emprunts)
				.iterator();
		// end-user-code
	}
}