/**
 * 
 */
package bibliotheque.metier.impl;

import bibliotheque.metier.IExemplaire;
import bibliotheque.metier.IEmprunt;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Exemplaire implements IExemplaire {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Emprunt emprunt;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private String key;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Ouvrage ouvrage;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Ouvrage getOuvrage() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.ouvrage;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean estEmprunte() {
		// begin-user-code
		// TODO Auto-generated method stub
		return (emprunt != null);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param emprunt
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setEmprunt(Emprunt emprunt) {
		// begin-user-code
		// TODO Auto-generated method stub
		this.emprunt = emprunt;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param identifiant
	 * @param ouvrage
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Exemplaire(String identifiant, Ouvrage ouvrage) {
		// begin-user-code
		this.ouvrage = ouvrage;
		this.key = identifiant;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String getIdentifiant() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.key;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Emprunt getEmprunt() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.emprunt;
		// end-user-code
	}
}