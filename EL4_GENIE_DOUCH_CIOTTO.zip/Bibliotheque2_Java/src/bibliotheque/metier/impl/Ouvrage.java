/**
 * 
 */
package bibliotheque.metier.impl;

import java.util.Iterator;

import bibliotheque.metier.GenreOuvrage;
import bibliotheque.metier.IAbonne;
import bibliotheque.metier.IAuteur;
import bibliotheque.metier.IEmprunt;
import bibliotheque.metier.IExemplaire;
import bibliotheque.metier.IOuvrage;

import java.util.Collections;
import java.util.HashMap;
import java.util.Set;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Ouvrage implements IOuvrage {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private HashMap<String, Exemplaire> exemplaires = new HashMap<String, Exemplaire>();
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private GenreOuvrage genre;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private String title;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Auteur auteur;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Bibliotheque bibliotheque;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public GenreOuvrage getGenre() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.genre;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param exemplaire
	 * @param key
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void ajouterExemplaire(Exemplaire exemplaire, String key) {
		// begin-user-code
		// TODO Auto-generated method stub
		this.exemplaires.put(key, exemplaire);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param auteur
	 * @param genre
	 * @param title
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Ouvrage(Auteur auteur, GenreOuvrage genre, String title) {
		// begin-user-code
		this.auteur = auteur;
		this.genre = genre;
		this.title = title;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String getTitre() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.title;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne l'auteur ayant �crit cet ouvrage</p>
	 * <!-- end-UML-doc -->
	 * @return <p>l'objet auteur associ�</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IAuteur getAuteur() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.auteur;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le nombre d'exemplaires de cet ouvrage.</p>
	 * <!-- end-UML-doc -->
	 * @return <p>le nombre d'exemplaires</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getNombreExemplaires() {
		// begin-user-code
		// TODO Auto-generated method stub
		return this.exemplaires.size();
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le nombre d'exemplaires de cet ouvrage emprunt�s</p>
	 * <!-- end-UML-doc -->
	 * @return <p>le nombre d'exemplaires emprunt�s</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getNombreEmprunts() {
		// begin-user-code
		// TODO Auto-generated method stub

		int nombre = 0;
		Iterator<IExemplaire> iterator = this.iterateurExemplaires();
		while (iterator.hasNext()) {

			Exemplaire exemplaire = (Exemplaire) iterator.next();

			if (exemplaire.estEmprunte())
				nombre++;
		}

		return nombre;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <p >M�thode permettant de parcourir les exemplaires de l'ouvrage.</p><p >Si, par exemple, vous stockez les exemplaires dans un HashSet nomm� exemplaires, vous pouvez utiliser le code suivant :</p><p class="codesample">return Collections.&lt;IExemplaire&gt; unmodifiableCollection(exemplaires).iterator();</p>
	 * <!-- end-UML-doc -->
	 * @return <p>un it�rateur sur les exemplaires de cet ouvrage.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Iterator<IExemplaire> iterateurExemplaires() {
		// begin-user-code
		// TODO Auto-generated method stub
		return Collections.<IExemplaire> unmodifiableCollection(
				exemplaires.values()).iterator();
		// end-user-code
	}
}