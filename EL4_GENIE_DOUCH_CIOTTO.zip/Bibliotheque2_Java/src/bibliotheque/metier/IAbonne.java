/**
 * 
 */
package bibliotheque.metier;

import bibliotheque.metier.impl.Emprunt;
import java.util.GregorianCalendar;
import java.util.Iterator;

/** 
 * <!-- begin-UML-doc -->
 * <p>Interface sp�cifiant les besoins d'acc�s � un abonn�.</p>
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public interface IAbonne {
	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le code-barres de l'abonn�.</p><p>l'IHM fournie suppose que ce code-barres est constitu� des deux lettres AB suivies d'un entier ; par exemple AB123</p><p></p>
	 * <!-- end-UML-doc -->
	 * @return <p>le code-barres de l'abonn�</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String getIdentifiant();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le malus actuel de l'abonn�.</p>
	 * <!-- end-UML-doc -->
	 * @return <p>malus de l'abonn�.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getMalus();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne la date du dernier jour de validit� de l'inscription de l'abonn�.</p><p></p>
	 * <!-- end-UML-doc -->
	 * @return <p> Date du dernier jour de validit� de l'inscription de l'abonn�.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public GregorianCalendar getDateFinValiditeInscription();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Op�ration effectu�e sur chaque abonn� ayant un malus non nul lors d'un changement de jour</p>
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void decrementeMalus();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le nombre d'emprunts en cours de l'abonn�</p>
	 * <!-- end-UML-doc -->
	 * @return <p>nombre d'emprunts en cours</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getNombreEmprunts();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Modifie le malus de l'abonn�.</p>
	 * <!-- end-UML-doc -->
	 * @param ajout <p>valeur � ajouter au malus courant.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void ajouteMalus(int ajout);

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le nom de l'abonn�.</p>
	 * <!-- end-UML-doc -->
	 * @return <p>nom de l'abonn�.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String getNom();

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param emprunt
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean restituer(Emprunt emprunt);

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param emprunt
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void emprunter(Emprunt emprunt);

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean peutEmprunter();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>M�thode permettant de parcourir les emprunts de l'abonn�.</p><p>Si, par exemple, vous stockez les emprunts dans un HashSet nomm� emprunts, vous pouvez utiliser le code suivant :</p><p class="codesample">return Collections.&lt;IEmprunt&gt; unmodifiableCollection(emprunts).iterator();</p>
	 * <!-- end-UML-doc -->
	 * @return <p>un it�rateur sur les emprunts en cours de l'abonn�.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Iterator<IEmprunt> iterateurEmprunts();
}