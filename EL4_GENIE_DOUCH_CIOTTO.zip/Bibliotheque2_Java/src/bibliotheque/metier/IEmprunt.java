/**
 * 
 */
package bibliotheque.metier;

import java.util.GregorianCalendar;

/** 
 * <!-- begin-UML-doc -->
 * <p>Interface sp�cifiant les besoins d'acc�s � un emprunt.</p>
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public interface IEmprunt {
	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne l'exemplaire emprunt�.</p>
	 * <!-- end-UML-doc -->
	 * @return <p>l'exemplaire emprunt�.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IExemplaire getExemplaire();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne la date de d�but de cet emprunt.</p>
	 * <!-- end-UML-doc -->
	 * @return <p>la date de d�but de cet emprunt.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public GregorianCalendar getDateDebut();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne l'abonn� ayant effectu� cet emprunt.</p>
	 * <!-- end-UML-doc -->
	 * @return <p> l'abonn� ayant effectu� cet emprunt.</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IAbonne getAbonne();

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Retourne le nombre de jours de d�passement de cet emprunt (0 s'il n'y a pas de d�passement).</p>
	 * <!-- end-UML-doc -->
	 * @param date <p>date actuelle</p>
	 * @return <p>le nombre de jours de d�passement de cet emprunt (0 s'il n'y a pas de d�passement).</p>
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public int getDepassementRestitution(GregorianCalendar date);

	/** 
	 * <!-- begin-UML-doc -->
	 * <p>Indique que l'exemplaire a �t� rendu et que l'emprunt est termin�.</p><p>L'abonn� ayant effectu� cet emprunt et l'exemplaire concern� n'ont pas �t� inform�s de cette fin d'emprunt : c'est le r�le de cette m�thode.</p>
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void termine();
}