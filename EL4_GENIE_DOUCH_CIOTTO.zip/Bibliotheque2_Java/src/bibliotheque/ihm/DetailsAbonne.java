/**
 * 
 */
package bibliotheque.ihm;

import bibliotheque.metier.IAbonne;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public abstract class DetailsAbonne extends Ecran {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected IAbonne abonne;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ihm
	 * @param abonne
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public DetailsAbonne(GestionnaireIHM ihm, IAbonne abonne) {
		// begin-user-code
		super(ihm);
		this.abonne = abonne;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected void chargement() {
		// begin-user-code

		// end-user-code
	}
}