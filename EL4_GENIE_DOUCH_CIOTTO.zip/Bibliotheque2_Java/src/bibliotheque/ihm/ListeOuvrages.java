/**
 * 
 */
package bibliotheque.ihm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

import bibliotheque.metier.IOuvrage;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public abstract class ListeOuvrages extends Ecran {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected ArrayList<IOuvrage> ouvrages = new ArrayList<IOuvrage>();

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected IOuvrage ouvrageSelectionne;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ihm
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ListeOuvrages(GestionnaireIHM ihm) {
		// begin-user-code
		super(ihm);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IOuvrage getOuvrageSelectionne() {
		// begin-user-code
		return ouvrageSelectionne;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected void chargement() {
		// begin-user-code
		ouvrages.clear();
		Iterator<IOuvrage> ouv = ihm.getControleur().getBibliotheque()
				.iterateurOuvrages();
		if (ouv == null)
			return;
		while (ouv.hasNext()) {
			ouvrages.add(ouv.next());
		}
		Collections.sort(ouvrages, new Comparator<IOuvrage>() {
			public int compare(IOuvrage o1, IOuvrage o2) {
				return o1.getTitre().compareTo(o2.getTitre());
			}
		});
		// end-user-code
	}
}