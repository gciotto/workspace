/**
 * 
 */
package bibliotheque.ihm.swt;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

import bibliotheque.ihm.DetailsAbonne;
import bibliotheque.ihm.DetailsOuvrage;
import bibliotheque.ihm.EcranPrincipal;
import bibliotheque.ihm.GestionnaireIHM;
import bibliotheque.ihm.ListeAbonnes;
import bibliotheque.ihm.ListeOuvrages;
import bibliotheque.metier.IAbonne;
import bibliotheque.metier.IBibliotheque;
import bibliotheque.metier.IOuvrage;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SWTGestionnaireIHM extends GestionnaireIHM {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Display display;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param shell
	 * @param message
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Integer lectureNombre(Shell shell, String message) {
		// begin-user-code
		SWTLectureNombre dialogue = new SWTLectureNombre(shell);
		return dialogue.open(message);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param shell
	 * @param message
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public String lectureChaine(Shell shell, String message) {
		// begin-user-code
		SWTLectureChaine dialogue = new SWTLectureChaine(shell);
		return dialogue.open(message);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SWTGestionnaireIHM() {
		// begin-user-code
		display = new Display();
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param message
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void alerte(String message) {
		// begin-user-code
		Shell shell = new Shell(display);
		MessageBox messageBox = new MessageBox(shell, SWT.ICON_ERROR);
		messageBox.setMessage(message);
		messageBox.open();
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param message
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public boolean confirme(String message) {
		// begin-user-code
		Shell shell = new Shell(display);
		MessageBox messageBox = new MessageBox(shell, SWT.YES | SWT.NO);
		messageBox.setMessage(message);
		int reponse = messageBox.open();
		return reponse == SWT.YES;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public EcranPrincipal ecranPrincipal() {
		// begin-user-code
		return new SWTEcranPrincipal(this);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param bibliotheque
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ListeAbonnes listeAbonnes(IBibliotheque bibliotheque) {
		// begin-user-code
		return new SWTListeAbonnes(this);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param abonne
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public DetailsAbonne detailsAbonne(IAbonne abonne) {
		// begin-user-code
		return new SWTDetailsAbonne(this, abonne);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param bibliotheque
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ListeOuvrages listeOuvrages(IBibliotheque bibliotheque) {
		// begin-user-code
		return new SWTListeOuvrages(this);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ouvrage
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public DetailsOuvrage detailsOuvrage(IOuvrage ouvrage) {
		// begin-user-code
		return new SWTDetailsOuvrage(this, ouvrage);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Display getDisplay() {
		// begin-user-code
		return display;
		// end-user-code
	}
}