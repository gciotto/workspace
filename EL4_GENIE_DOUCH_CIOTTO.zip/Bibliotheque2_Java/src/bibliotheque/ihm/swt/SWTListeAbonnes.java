/**
 * 
 */
package bibliotheque.ihm.swt;

import java.text.DateFormat;
import java.util.Iterator;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import bibliotheque.ihm.Evenement;
import bibliotheque.ihm.ListeAbonnes;
import bibliotheque.metier.IAbonne;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SWTListeAbonnes extends ListeAbonnes {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Evenement evenement;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Table table;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private String nom;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Evenement affiche() {
		// begin-user-code
		final SWTGestionnaireIHM ihm = (SWTGestionnaireIHM) this.ihm;
		final Shell shell = new Shell(ihm.getDisplay());
		shell.setText("Liste des abonn�s");
		FormLayout layout = new FormLayout();
		layout.marginWidth = 3;
		layout.marginHeight = 3;
		shell.setLayout(layout);
		shell.addShellListener(new ShellAdapter() {
			public void shellClosed(ShellEvent e) {
				if (evenement == null) {
					evenement = Evenement.quitter;
				}
			}
		});

		final Button details = new Button(shell, SWT.CENTER);
		details.setText("D�tails");
		FormData fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(0, 10);
		fd.width = 200;
		details.setLayoutData(fd);
		details.setEnabled(false);
		details.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				evenement = Evenement.details;
				shell.close();
			}
		});

		Button principal = new Button(shell, SWT.CENTER);
		principal.setText("�cran principal");
		fd = new FormData();
		fd.left = new FormAttachment(details, 10);
		fd.top = new FormAttachment(0, 10);
		fd.width = 200;
		principal.setLayoutData(fd);
		principal.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				evenement = Evenement.ecranPrincipal;
				shell.close();
			}
		});

		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(details, 20);
		fd.bottom = new FormAttachment(100, -10);
		table.setLayoutData(fd);
		final String[] titles = { "Nom", "Identifiant",
				"Fin de validit� inscription", "Nombre d'emprunts" };
		for (int i = 0; i < titles.length; i++) {
			TableColumn column = new TableColumn(table, SWT.NONE);
			column.setText(titles[i]);
		}
		chargement();
		table.addListener(SWT.MouseDown, new Listener() {
			public void handleEvent(Event event) {
				details.setEnabled(true);
				Point pt = new Point(event.x, event.y);
				TableItem item = table.getItem(pt);
				if (item == null)
					return;
				for (int i = 0; i < table.getColumnCount(); i++) {
					Rectangle rect = item.getBounds(i);
					if (rect.contains(pt)) {
						abonneSelectionne = abonnes.get(table.indexOf(item));
					}
				}
			}
		});

		Button plus = new Button(shell, SWT.CENTER);
		plus.setText("+");
		fd = new FormData();
		fd.left = new FormAttachment(table, 10);
		fd.top = new FormAttachment(details, 20);
		fd.width = 40;
		plus.setLayoutData(fd);
		plus.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				nom = ihm.lectureChaine(shell, "Nom du nouvel abonn� ?");
				if (nom != null) {
					evenement = Evenement.ajout;
				}
			}
		});

		Button moins = new Button(shell, SWT.CENTER);
		moins.setText("-");
		fd = new FormData();
		fd.left = new FormAttachment(table, 10);
		fd.top = new FormAttachment(plus, 20);
		fd.width = 40;
		moins.setLayoutData(fd);
		moins.setEnabled(false);
		moins.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				evenement = Evenement.retrait;
			}
		});

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			evenement = null;
			if (!ihm.getDisplay().readAndDispatch())
				ihm.getDisplay().sleep();
			if (evenement == Evenement.ajout) {
				ihm.getControleur()
						.getBibliotheque()
						.nouvelAbonne(nom,
								ihm.getControleur().getDateCourante());
				chargement();
			}
		}

		return evenement;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ihm
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SWTListeAbonnes(SWTGestionnaireIHM ihm) {
		// begin-user-code
		super(ihm);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected void chargement() {
		// begin-user-code
		super.chargement();
		Iterator<IAbonne> iterator = abonnes.iterator();
		DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
		int itemCount = 0;
		while (iterator.hasNext()) {
			TableItem item;
			if (itemCount < table.getItemCount())
				item = table.getItem(itemCount);
			else
				item = new TableItem(table, SWT.NONE);
			IAbonne abonne = iterator.next();
			item.setText(0, abonne.getNom());
			item.setText(1, abonne.getIdentifiant());
			item.setText(2,
					df.format(abonne.getDateFinValiditeInscription().getTime()));
			item.setText(3, "" + abonne.getNombreEmprunts());
			++itemCount;
		}
		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumn(i).pack();
		}
		// end-user-code
	}
}