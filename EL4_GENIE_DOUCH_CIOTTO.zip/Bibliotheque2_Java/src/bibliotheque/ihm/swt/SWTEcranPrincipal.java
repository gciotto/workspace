/**
 * 
 */
package bibliotheque.ihm.swt;

import java.text.DateFormat;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

import bibliotheque.ihm.EcranPrincipal;
import bibliotheque.ihm.Evenement;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SWTEcranPrincipal extends EcranPrincipal {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Evenement evenement;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Evenement affiche() {
		// begin-user-code
		final SWTGestionnaireIHM ihm = (SWTGestionnaireIHM) this.ihm;
		final Shell shell = new Shell(ihm.getDisplay());
		shell.setText("Ecran principal");
		FormLayout layout = new FormLayout();
		layout.marginWidth = 3;
		layout.marginHeight = 3;
		shell.setLayout(layout);
		shell.addShellListener(new ShellAdapter() {
			public void shellClosed(ShellEvent e) {
				if (evenement == null) {
					evenement = Evenement.quitter;
				}
			}
		});

		Label label = new Label(shell, SWT.CENTER);
		label.setText("Date courante : ");
		FormData fd = new FormData();
		fd.left = new FormAttachment(0, 50);
		fd.top = new FormAttachment(0, 15);
		label.setLayoutData(fd);

		final Label date = new Label(shell, SWT.CENTER);
		final DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
		date.setText(df.format(ihm.getControleur().getDateCourante().getTime()));
		fd = new FormData();
		fd.left = new FormAttachment(label, 10);
		fd.top = new FormAttachment(0, 15);
		date.setLayoutData(fd);

		Button plus = new Button(shell, SWT.CENTER);
		plus.setText("+");
		fd = new FormData();
		fd.left = new FormAttachment(date, 10);
		fd.top = new FormAttachment(0, 10);
		fd.width = 40;
		plus.setLayoutData(fd);
		plus.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				ihm.getControleur().incrementeDate();
				date.setText(df.format(ihm.getControleur().getDateCourante()
						.getTime()));
			}
		});

		Button listeAbonnes = new Button(shell, SWT.CENTER);
		listeAbonnes.setText("Liste des abonn�s");
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(label, 20);
		fd.width = 200;
		listeAbonnes.setLayoutData(fd);
		listeAbonnes.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				evenement = Evenement.listeAbonnes;
				shell.close();
			}
		});

		Button listeOuvrages = new Button(shell, SWT.CENTER);
		listeOuvrages.setText("Liste des ouvrages");
		fd = new FormData();
		fd.left = new FormAttachment(listeAbonnes, 10);
		fd.top = new FormAttachment(label, 20);
		fd.width = 200;
		listeOuvrages.setLayoutData(fd);
		listeOuvrages.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				evenement = Evenement.listeOuvrages;
				shell.close();
			}
		});

		Button codeAbonne = new Button(shell, SWT.CENTER);
		codeAbonne.setText("Code-barres abonn�");
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(listeAbonnes, 10);
		fd.width = 200;
		codeAbonne.setLayoutData(fd);
		codeAbonne.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				codeBarres = ihm.lectureNombre(shell, "Code d'un abonn� AB");
				if (codeBarres != null) {
					evenement = Evenement.codeBarresAbonne;
					shell.close();
				}
			}
		});

		Button codeExemplaire = new Button(shell, SWT.CENTER);
		codeExemplaire.setText("Code-barres exemplaire");
		fd = new FormData();
		fd.left = new FormAttachment(codeAbonne, 10);
		// fd.right = new FormAttachment(100, -10);
		fd.top = new FormAttachment(listeOuvrages, 10);
		fd.width = 200;
		codeExemplaire.setLayoutData(fd);
		codeExemplaire.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				codeBarres = ihm
						.lectureNombre(shell, "Code d'un exemplaire EX");
				if (codeBarres != null) {
					evenement = Evenement.codeBarresExemplaire;
					shell.close();
				}
			}
		});

		shell.pack();
		shell.open();

		while (!shell.isDisposed()) {
			evenement = null;
			if (!ihm.getDisplay().readAndDispatch())
				ihm.getDisplay().sleep();
		}

		return evenement;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ihm
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SWTEcranPrincipal(SWTGestionnaireIHM ihm) {
		// begin-user-code
		super(ihm);
		// end-user-code
	}
}