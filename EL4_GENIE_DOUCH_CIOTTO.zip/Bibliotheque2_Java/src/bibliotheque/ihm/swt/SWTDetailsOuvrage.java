/**
 * 
 */
package bibliotheque.ihm.swt;

import java.text.DateFormat;
import java.util.Iterator;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import bibliotheque.ihm.DetailsOuvrage;
import bibliotheque.ihm.Evenement;
import bibliotheque.metier.IEmprunt;
import bibliotheque.metier.IExemplaire;
import bibliotheque.metier.IOuvrage;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SWTDetailsOuvrage extends DetailsOuvrage {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Evenement evenement;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Table table;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Evenement affiche() {
		// begin-user-code
		SWTGestionnaireIHM ihm = (SWTGestionnaireIHM) this.ihm;
		final Shell shell = new Shell(ihm.getDisplay());
		shell.setText("D�tails d'un ouvrage");
		FormLayout layout = new FormLayout();
		layout.marginWidth = 3;
		layout.marginHeight = 3;
		shell.setLayout(layout);
		shell.addShellListener(new ShellAdapter() {
			public void shellClosed(ShellEvent e) {
				if (evenement == null) {
					evenement = Evenement.quitter;
				}
			}
		});

		Button liste = new Button(shell, SWT.CENTER);
		liste.setText("Liste des ouvrages");
		FormData fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(0, 10);
		fd.width = 200;
		liste.setLayoutData(fd);
		liste.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				evenement = Evenement.listeOuvrages;
				shell.close();
			}
		});

		Button principal = new Button(shell, SWT.CENTER);
		principal.setText("�cran principal");
		fd = new FormData();
		fd.left = new FormAttachment(liste, 10);
		fd.top = new FormAttachment(0, 10);
		fd.width = 200;
		principal.setLayoutData(fd);
		principal.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				evenement = Evenement.ecranPrincipal;
				shell.close();
			}
		});

		Label titre = new Label(shell, SWT.CENTER);
		titre.setText("Titre : " + ouvrage.getTitre());
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(liste, 10);
		titre.setLayoutData(fd);

		Label auteur = new Label(shell, SWT.CENTER);
		auteur.setText("Auteur : " + ouvrage.getAuteur().getNom());
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(titre, 10);
		auteur.setLayoutData(fd);

		Label genre = new Label(shell, SWT.CENTER);
		genre.setText("Genre : " + ouvrage.getGenre().name());
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(auteur, 10);
		genre.setLayoutData(fd);

		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(genre, 20);
		fd.right = new FormAttachment(100, -10);
		fd.bottom = new FormAttachment(100, -10);
		table.setLayoutData(fd);

		final String[] titles = { "Exemplaire", "Emprunteur", "Date d'emprunt",
				"Retard" };
		for (int i = 0; i < titles.length; i++) {
			TableColumn column = new TableColumn(table, SWT.NONE);
			column.setText(titles[i]);
		}
		chargement();

		shell.pack();
		shell.open();
		if (restitutionDemandee != null) {
			if (ihm.confirme("Restitution de l'exemplaire "
					+ restitutionDemandee.getIdentifiant() + " ?")) {
				String message = ihm
						.getControleur()
						.getBibliotheque()
						.nouvelleRestitution(restitutionDemandee,
								ihm.getControleur().getDateCourante());
				if (message != null)
					ihm.alerte(message);
				chargement();
			}
		}
		while (!shell.isDisposed()) {
			evenement = null;
			if (!ihm.getDisplay().readAndDispatch())
				ihm.getDisplay().sleep();
		}

		return evenement;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ihm
	 * @param ouvrage
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SWTDetailsOuvrage(SWTGestionnaireIHM ihm, IOuvrage ouvrage) {
		// begin-user-code
		super(ihm, ouvrage);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected void chargement() {
		// begin-user-code
		table.removeAll();
		Iterator<IExemplaire> iterator = ouvrage.iterateurExemplaires();
		DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
		while (iterator.hasNext()) {
			TableItem item = new TableItem(table, SWT.NONE);
			IExemplaire exemplaire = iterator.next();
			IEmprunt emprunt = exemplaire.getEmprunt();
			item.setText(0, exemplaire.getIdentifiant());
			if (emprunt != null) {
				item.setText(1, emprunt.getAbonne().getNom() + " ("
						+ emprunt.getAbonne().getIdentifiant() + ")");
				item.setText(2, df.format(emprunt.getDateDebut().getTime()));
				if (exemplaire.getEmprunt() != null) {
					int retard = 0;
					retard = exemplaire.getEmprunt().getDepassementRestitution(
							ihm.getControleur().getDateCourante());
					item.setText(3, "" + retard);
				} else {
					item.setText(3, "");
				}
			}
		}
		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumn(i).pack();
		}
		// end-user-code
	}
}