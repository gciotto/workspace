/**
 * 
 */
package bibliotheque.ihm.swt;

import java.text.DateFormat;
import java.util.Iterator;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import bibliotheque.ihm.DetailsAbonne;
import bibliotheque.ihm.Evenement;
import bibliotheque.metier.IAbonne;
import bibliotheque.metier.IEmprunt;
import bibliotheque.metier.IExemplaire;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class SWTDetailsAbonne extends DetailsAbonne {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Evenement evenement;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Table table;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private String codeBarres;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Evenement affiche() {
		// begin-user-code
		final SWTGestionnaireIHM ihm = (SWTGestionnaireIHM) this.ihm;
		final Shell shell = new Shell(ihm.getDisplay());
		shell.setText("D�tails d'un abonn�");
		FormLayout layout = new FormLayout();
		layout.marginWidth = 3;
		layout.marginHeight = 3;
		shell.setLayout(layout);
		shell.addShellListener(new ShellAdapter() {
			public void shellClosed(ShellEvent e) {
				if (evenement == null) {
					evenement = Evenement.quitter;
				}
			}
		});

		Button code = new Button(shell, SWT.CENTER);
		code.setText("Code-barres exemplaire");
		FormData fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(0, 10);
		fd.width = 200;
		code.setLayoutData(fd);
		code.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				codeBarres = ihm
						.lectureChaine(shell, "Code d'un exemplaire EX");
				if (codeBarres != null) {
					evenement = Evenement.codeBarresExemplaire;
					// shell.close ();
				}
			}
		});

		Button liste = new Button(shell, SWT.CENTER);
		liste.setText("Liste des abonn�s");
		fd = new FormData();
		fd.left = new FormAttachment(code, 10);
		fd.top = new FormAttachment(0, 10);
		fd.width = 200;
		liste.setLayoutData(fd);
		liste.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				evenement = Evenement.listeAbonnes;
				shell.close();
			}
		});

		Button principal = new Button(shell, SWT.CENTER);
		principal.setText("�cran principal");
		fd = new FormData();
		fd.left = new FormAttachment(liste, 10);
		fd.top = new FormAttachment(0, 10);
		fd.width = 200;
		principal.setLayoutData(fd);
		principal.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				evenement = Evenement.ecranPrincipal;
				shell.close();
			}
		});

		Label nom = new Label(shell, SWT.CENTER);
		nom.setText("Nom : " + abonne.getNom());
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(code, 10);
		nom.setLayoutData(fd);

		Label id = new Label(shell, SWT.CENTER);
		id.setText("Identifiant : " + abonne.getIdentifiant());
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(nom, 10);
		id.setLayoutData(fd);

		Label inscription = new Label(shell, SWT.CENTER);
		DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
		inscription.setText("Validit� inscription : "
				+ df.format(abonne.getDateFinValiditeInscription().getTime()));
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(id, 10);
		inscription.setLayoutData(fd);

		Label malus = new Label(shell, SWT.CENTER);
		malus.setText("Malus : " + abonne.getMalus());
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(inscription, 10);
		malus.setLayoutData(fd);

		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table.setLinesVisible(true);
		table.setHeaderVisible(true);
		fd = new FormData();
		fd.left = new FormAttachment(0, 10);
		fd.top = new FormAttachment(malus, 20);
		fd.right = new FormAttachment(100, -10);
		fd.bottom = new FormAttachment(100, -10);
		table.setLayoutData(fd);

		final String[] titles = { "Exemplaire", "Titre", "Auteur", "Genre",
				"Date d'emprunt", "Retard" };
		for (int i = 0; i < titles.length; i++) {
			TableColumn column = new TableColumn(table, SWT.NONE);
			column.setText(titles[i]);
		}
		chargement();

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			evenement = null;
			if (!ihm.getDisplay().readAndDispatch())
				ihm.getDisplay().sleep();
			if (evenement == Evenement.codeBarresExemplaire) {
				IExemplaire ex = ihm.getControleur().getBibliotheque()
						.trouveExemplaire("EX" + codeBarres);
				if (ex == null) {
					ihm.alerte("Exemplaire " + codeBarres + " inconnu");
				} else if (ihm.confirme("Emprunt de l'exemplaire EX"
						+ codeBarres + " ?")) {
					String message = ihm
							.getControleur()
							.getBibliotheque()
							.nouvelEmprunt(abonne, ex,
									ihm.getControleur().getDateCourante());
					if (message != null)
						ihm.alerte(message);
					chargement();
				}
			}
		}

		return evenement;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ihm
	 * @param abonne
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public SWTDetailsAbonne(SWTGestionnaireIHM ihm, IAbonne abonne) {
		// begin-user-code
		super(ihm, abonne);
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected void chargement() {
		// begin-user-code
		Iterator<IEmprunt> iterator = abonne.iterateurEmprunts();
		table.removeAll();
		DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
		while (iterator.hasNext()) {
			TableItem item = new TableItem(table, SWT.NONE);
			IEmprunt emprunt = iterator.next();
			IExemplaire exemplaire = emprunt.getExemplaire();
			item.setText(0, exemplaire.getIdentifiant());
			item.setText(1, exemplaire.getOuvrage().getTitre());
			item.setText(2, exemplaire.getOuvrage().getAuteur().getNom());
			item.setText(3, exemplaire.getOuvrage().getGenre().name());
			item.setText(4, df.format(emprunt.getDateDebut().getTime()));
			int retard = 0;
			retard = emprunt.getDepassementRestitution(ihm.getControleur()
					.getDateCourante());
			item.setText(5, "" + retard);
		}
		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumn(i).pack();
		}
		// end-user-code
	}
}