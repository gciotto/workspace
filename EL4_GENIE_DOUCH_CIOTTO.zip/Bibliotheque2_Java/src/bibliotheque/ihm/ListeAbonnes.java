/**
 * 
 */
package bibliotheque.ihm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

import bibliotheque.metier.IAbonne;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public abstract class ListeAbonnes extends Ecran {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected ArrayList<IAbonne> abonnes = new ArrayList<IAbonne>();

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected IAbonne abonneSelectionne;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ihm
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ListeAbonnes(GestionnaireIHM ihm) {
		// begin-user-code
		super(ihm);
		abonnes = new ArrayList<IAbonne>();
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IAbonne getAbonneSelectionne() {
		// begin-user-code
		return abonneSelectionne;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected void chargement() {
		// begin-user-code
		abonnes.clear();
		Iterator<IAbonne> abo = ihm.getControleur().getBibliotheque()
				.iterateurAbonnes();
		if (abo == null)
			return;
		while (abo.hasNext()) {
			abonnes.add(abo.next());
		}
		Collections.sort(abonnes, new Comparator<IAbonne>() {
			public int compare(IAbonne o1, IAbonne o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		// end-user-code
	}
}