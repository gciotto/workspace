/**
 * 
 */
package bibliotheque.ihm;

import java.util.GregorianCalendar;
import java.util.Iterator;

import bibliotheque.metier.IAbonne;
import bibliotheque.metier.IBibliotheque;
import bibliotheque.metier.IExemplaire;
import bibliotheque.metier.IOuvrage;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class ControleurBibliotheque {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private GregorianCalendar dateCourante;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private GestionnaireIHM ihm;
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private IBibliotheque bibliotheque;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public GregorianCalendar getDateCourante() {
		// begin-user-code
		return (GregorianCalendar) dateCourante.clone();
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ihm
	 * @param bibliotheque
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public ControleurBibliotheque(GestionnaireIHM ihm,
			IBibliotheque bibliotheque) {
		// begin-user-code
		this.ihm = ihm;
		this.ihm.setControleur(this);
		this.bibliotheque = bibliotheque;
		this.dateCourante = new GregorianCalendar();
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void lancement() {
		// begin-user-code
		Ecran ecran = ihm.ecranPrincipal();
		while (true) {
			Evenement ev = ecran.affiche();
			Integer codeBarres = null;
			IAbonne abonneSelectionne = null;
			IOuvrage ouvrageSelectionne = null;
			if (ecran instanceof EcranPrincipal) {
				codeBarres = ((EcranPrincipal) ecran).getCodeBarres();
			} else if (ecran instanceof ListeAbonnes) {
				abonneSelectionne = ((ListeAbonnes) ecran)
						.getAbonneSelectionne();
			} else if (ecran instanceof ListeOuvrages) {
				ouvrageSelectionne = ((ListeOuvrages) ecran)
						.getOuvrageSelectionne();
			}
			switch (ev) {
			case ecranPrincipal:
				ecran = ihm.ecranPrincipal();
				break;
			case listeAbonnes:
				ecran = ihm.listeAbonnes(bibliotheque);
				break;
			case listeOuvrages:
				ecran = ihm.listeOuvrages(bibliotheque);
				break;
			case details:
				if (ecran instanceof ListeAbonnes) {
					ecran = ihm.detailsAbonne(abonneSelectionne);
				} else if (ecran instanceof ListeOuvrages) {
					ecran = ihm.detailsOuvrage(ouvrageSelectionne);
				}
				break;
			case codeBarresAbonne:
				IAbonne abonne = bibliotheque.trouveAbonne("AB" + codeBarres);
				if (abonne == null) {
					ihm.alerte("Abonn� AB" + codeBarres + " inconnu");
					ecran = ihm.ecranPrincipal();
				} else {
					ecran = ihm.detailsAbonne(abonne);
				}
				break;
			case codeBarresExemplaire:
				IExemplaire exemplaire = bibliotheque.trouveExemplaire("EX"
						+ codeBarres);
				if (exemplaire == null) {
					ihm.alerte("Exemplaire EX" + codeBarres + " inconnu");
					ecran = ihm.ecranPrincipal();
				} else if (exemplaire.getEmprunt() == null) {
					ihm.alerte("Exemplaire EX" + codeBarres + " nom emprunt�");
					ecran = ihm.ecranPrincipal();
				} else {
					ecran = ihm.detailsOuvrage(exemplaire.getOuvrage());
					((DetailsOuvrage) ecran).setRestitutionDemandee(exemplaire);
				}
				break;
			case quitter:
				System.exit(0);
			}
		}
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void incrementeDate() {
		// begin-user-code
		dateCourante.add(GregorianCalendar.DAY_OF_YEAR, 1);
		Iterator<IAbonne> iterator = bibliotheque.iterateurAbonnes();
		while (iterator.hasNext()) {
			IAbonne abonne = iterator.next();
			if (abonne.getMalus() > 0) {
				abonne.decrementeMalus();
			}
		}
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public IBibliotheque getBibliotheque() {
		// begin-user-code
		return bibliotheque;
		// end-user-code
	}
}