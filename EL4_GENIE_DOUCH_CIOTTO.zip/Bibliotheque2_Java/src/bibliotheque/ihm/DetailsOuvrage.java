/**
 * 
 */
package bibliotheque.ihm;

import bibliotheque.metier.IExemplaire;
import bibliotheque.metier.IOuvrage;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public abstract class DetailsOuvrage extends Ecran {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected IOuvrage ouvrage;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected IExemplaire restitutionDemandee = null;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param ihm
	 * @param ouvrage
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public DetailsOuvrage(GestionnaireIHM ihm, IOuvrage ouvrage) {
		// begin-user-code
		super(ihm);
		this.ouvrage = ouvrage;
		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	protected void chargement() {
		// begin-user-code

		// end-user-code
	}

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param exemplaire
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setRestitutionDemandee(IExemplaire exemplaire) {
		// begin-user-code
		restitutionDemandee = exemplaire;
		// end-user-code
	}
}