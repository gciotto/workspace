/**
 * 
 */
package bibliotheque.util;

import java.util.GregorianCalendar;

import bibliotheque.metier.GenreOuvrage;
import bibliotheque.metier.IBibliotheque;

/** 
 * <!-- begin-UML-doc -->
 * <p>Classe permettant de charger la bibliotheque avec des exemplaires, des abonn�s</p>
 * <!-- end-UML-doc -->
 * @author ciottopinton_gus
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class ChargementBibliotheque {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param bibliotheque
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public static void chargement(IBibliotheque bibliotheque) {
		// begin-user-code

		bibliotheque.nouvelAbonne("Bianca Castafiore", new GregorianCalendar(
				2012, 1, 1));
		bibliotheque.nouvelAbonne("Quasimodo",
				new GregorianCalendar(2012, 2, 1));
		bibliotheque.nouvelAbonne("Alcide Nikopol", new GregorianCalendar(2012,
				3, 1));
		bibliotheque.nouvelAbonne("Jill Bioskop", new GregorianCalendar(2012,
				4, 1));
		bibliotheque.nouvelAbonne("Pietr Johannson", new GregorianCalendar(
				2012, 5, 1));
		bibliotheque.nouvelAbonne("Landry Barbeau", new GregorianCalendar(2012,
				6, 1));
		bibliotheque.nouvelAbonne("Victorien Salagnon", new GregorianCalendar(
				2012, 7, 1));
		bibliotheque.nouvelAbonne("R. Daneel Olivaw", new GregorianCalendar(
				2012, 8, 1));
		bibliotheque.nouvelAbonne("Elijah Baley", new GregorianCalendar(2012,
				9, 1));
		bibliotheque.nouvelAbonne("Hari Seldon", new GregorianCalendar(2012,
				10, 1));
		bibliotheque.nouvelAbonne("Lucas Reynard", new GregorianCalendar(2012,
				11, 1));
		bibliotheque.nouvelAbonne("Carl Corey", new GregorianCalendar(2012, 12,
				1));

		bibliotheque.nouvelOuvrage("Le Lotus bleu", "Herg�",
				GenreOuvrage.bandeDessinee, 1);
		bibliotheque.nouvelOuvrage("Le Crabe aux pinces d'or,", "Herg�",
				GenreOuvrage.bandeDessinee, 2);
		bibliotheque.nouvelOuvrage("Le Secret de la Licorne", "Herg�",
				GenreOuvrage.bandeDessinee, 3);

		bibliotheque.nouvelOuvrage("La Foire aux immortels", "Enki Bilal",
				GenreOuvrage.bandeDessinee, 5);
		bibliotheque.nouvelOuvrage("La Femme pi�ge", "Enki Bilal",
				GenreOuvrage.bandeDessinee, 2);
		bibliotheque.nouvelOuvrage("Froid �quateur", "Enki Bilal",
				GenreOuvrage.bandeDessinee, 1);

		bibliotheque.nouvelOuvrage("Pietr-le-Letton", "Georges Simenon",
				GenreOuvrage.policier, 1);
		bibliotheque.nouvelOuvrage("Le Charretier de la Providence",
				"Georges Simenon", GenreOuvrage.policier, 1);
		bibliotheque.nouvelOuvrage("M. Gallet d�c�d�", "Georges Simenon",
				GenreOuvrage.policier, 1);
		bibliotheque.nouvelOuvrage("Le Pendu de Saint-Pholien",
				"Georges Simenon", GenreOuvrage.policier, 1);
		bibliotheque.nouvelOuvrage("Maigret et Monsieur Charles",
				"Georges Simenon", GenreOuvrage.policier, 1);

		bibliotheque.nouvelOuvrage("Le Retour d'Hercule Poirot",
				"Agatha Christie", GenreOuvrage.policier, 2);
		bibliotheque.nouvelOuvrage("Hercule Poirot quitte la sc�ne",
				"Agatha Christie", GenreOuvrage.policier, 2);

		bibliotheque.nouvelOuvrage("Notre Dame de Paris", "Victor Hugo",
				GenreOuvrage.roman, 1);
		bibliotheque.nouvelOuvrage("Le Comte de Monte-Cristo",
				"Alexandre Dumas", GenreOuvrage.roman, 1);
		bibliotheque.nouvelOuvrage("La Petite Fadette", "George Sand",
				GenreOuvrage.roman, 1);
		bibliotheque.nouvelOuvrage("Agar dans le d�sert", "Madame de Sta�l",
				GenreOuvrage.roman, 1);
		bibliotheque.nouvelOuvrage("Trois Femmes puissantes", "Marie NDiaye",
				GenreOuvrage.roman, 3);
		bibliotheque.nouvelOuvrage("La Carte et le Territoire",
				"Michel Houellebecq", GenreOuvrage.roman, 3);
		bibliotheque.nouvelOuvrage("L'Art fran�ais de la guerre",
				"Alexis Jenni", GenreOuvrage.roman, 3);

		bibliotheque.nouvelOuvrage("Les Cavernes d'acier", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);
		bibliotheque.nouvelOuvrage("Face aux feux du soleil", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);
		bibliotheque.nouvelOuvrage("Les Robots de l'aube", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);
		bibliotheque.nouvelOuvrage("Les Robots et l'Empire", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);
		bibliotheque.nouvelOuvrage("Pr�lude � Fondation", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);
		bibliotheque.nouvelOuvrage("l'Aube de Fondation", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);
		bibliotheque.nouvelOuvrage("Fondation", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);
		bibliotheque.nouvelOuvrage("Fondation et Empire", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);
		bibliotheque.nouvelOuvrage("Seconde Fondation", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);
		bibliotheque.nouvelOuvrage("Fondation foudroy�e", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);
		bibliotheque.nouvelOuvrage("Terre et Fondation", "Isaac Asimov",
				GenreOuvrage.sciencefiction, 1);

		bibliotheque.nouvelOuvrage("Les Neuf Princes d'Ambre", "Roger Zelazny",
				GenreOuvrage.sciencefiction, 2);
		bibliotheque.nouvelOuvrage("Les Fusils d'Avalon", "Roger Zelazny",
				GenreOuvrage.sciencefiction, 2);
		bibliotheque.nouvelOuvrage("Le Signe de la Licorne", "Roger Zelazny",
				GenreOuvrage.sciencefiction, 2);
		bibliotheque.nouvelOuvrage("La Main d'Ob�ron", "Roger Zelazny",
				GenreOuvrage.sciencefiction, 2);
		bibliotheque.nouvelOuvrage("Les Cours du Chaos", "Roger Zelazny",
				GenreOuvrage.sciencefiction, 2);
		bibliotheque.nouvelOuvrage("Les Atouts de la vengeance",
				"Roger Zelazny", GenreOuvrage.sciencefiction, 2);
		bibliotheque.nouvelOuvrage("Le Sang d'Ambre", "Roger Zelazny",
				GenreOuvrage.sciencefiction, 2);
		bibliotheque.nouvelOuvrage("Le Signe du Chaos", "Roger Zelazny",
				GenreOuvrage.sciencefiction, 2);
		bibliotheque.nouvelOuvrage("Chevalier des Ombres", "Roger Zelazny",
				GenreOuvrage.sciencefiction, 2);
		bibliotheque.nouvelOuvrage("Prince du Chaos", "Roger Zelazny",
				GenreOuvrage.sciencefiction, 2);
		// end-user-code
	}
}